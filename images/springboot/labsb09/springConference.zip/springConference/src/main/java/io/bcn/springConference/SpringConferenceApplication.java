package io.bcn.springConference;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringConferenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConferenceApplication.class, args);
	}

}
