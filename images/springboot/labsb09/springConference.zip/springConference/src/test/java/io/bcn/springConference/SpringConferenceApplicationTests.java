package io.bcn.springConference;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConferenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
